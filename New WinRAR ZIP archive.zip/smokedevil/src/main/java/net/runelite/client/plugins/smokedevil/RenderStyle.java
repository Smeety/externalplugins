package net.runelite.client.plugins.smokedevil;

    public enum RenderStyle
    {
        OFF,
        TILE,
        THIN_TILE,
        HULL,
        SOUTH_WEST_TILE,
        THIN_OUTLINE,
        OUTLINE,
        THIN_GLOW,
        GLOW,
        TRUE_LOCATIONS,
        THIN_TRUE_LOCATIONS
    }